﻿using UnityEngine;

namespace PROJECT3D
{
    public abstract class UnitSkill : MonoBehaviour
    {
        private SkillDef skillDef;

        public virtual void ApplySkill()
        {
            
        }
    }
}